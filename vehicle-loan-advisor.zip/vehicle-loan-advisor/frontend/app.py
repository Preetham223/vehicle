﻿import os

import requests
import streamlit as st


API_URL = os.getenv("SAARATHI_API_URL", "http://127.0.0.1:8000")

st.set_page_config(page_title="Vehicle Loan Advisor", page_icon="🚗")
st.title("Intelligent Vehicle Loan Advisor")
st.write("Check eligibility, estimate a loan amount, and explore affordable vehicles.")

with st.form("application_form"):
    age = st.number_input("Age", min_value=18, max_value=75, value=35)
    monthly_income = st.number_input("Monthly income (INR)", min_value=1, value=60000)
    credit_score = st.number_input("Credit score", min_value=300, max_value=900, value=720)
    employment_type = st.selectbox("Employment type", ["salaried", "self_employed"])
    employment_years = st.number_input("Employment experience (years)", min_value=0.0, value=5.0)
    current_employment_months = st.number_input("Months with current employer", min_value=0, value=24)
    dependents = st.number_input("Dependents", min_value=0, value=1)
    residence_type = st.selectbox("Residence", ["owned", "rented"])
    existing_emi = st.number_input("Existing monthly EMIs (INR)", min_value=0, value=10000)
    tenure = st.selectbox("Requested tenure (months)", [12, 24, 36, 48, 60, 72, 84], index=4)
    down_payment = st.number_input("Down payment (INR)", min_value=0, value=100000)
    language = st.selectbox("Explanation language", ["English", "Hindi", "Telugu", "Tamil"])
    submitted = st.form_submit_button("Get loan assessment")


if submitted:
    payload = {
        "applicant": {
            "age": age,
            "monthly_income_inr": monthly_income,
            "credit_score": credit_score,
            "employment_years": employment_years,
            "current_employment_months": current_employment_months,
            "employment_type": employment_type,
            "dependents": dependents,
            "residence_type": residence_type,
            "existing_emi_inr": existing_emi,
            "requested_tenure_months": tenure,
            "down_payment_inr": down_payment,
        },
        "language": language,
    }

    try:
        response = requests.post(
            f"{API_URL}/application",
            json=payload,
            timeout=90,
        )
        response.raise_for_status()
        st.session_state["application_result"] = response.json()
    except requests.RequestException as error:
        st.error(f"Could not complete the assessment: {error}")


result = st.session_state.get("application_result")

if result:
    eligibility = result["eligibility"]
    loan = result["loan"]
    explanation = result["explanation"]

    st.subheader(f"Decision: {eligibility['decision']}")
    st.write(f"Model prediction: {eligibility['model_decision']}")

    for violation in eligibility.get("policy_violations", []):
        st.warning(violation["message"])

    if loan:
        st.metric("Estimated sanctioned amount", f"INR {loan['sanctioned_amount_inr']:,.0f}")
        st.metric("Estimated monthly EMI", f"INR {loan['monthly_emi_inr']:,.0f}")

    vehicles = result.get("vehicles", [])
    st.subheader("Vehicles within budget")
    if vehicles:
        st.dataframe(vehicles, use_container_width=True)
        vehicle_ids = list(dict.fromkeys(str(v["vehicle_id"]) for v in vehicles))
        selected_id = st.selectbox("Choose a vehicle ID", vehicle_ids)

        if st.button("Show vehicle variants and details"):
            try:
                details = requests.get(
                    f"{API_URL}/vehicles/{selected_id}",
                    timeout=30,
                )
                details.raise_for_status()
                st.json(details.json())
            except requests.RequestException as error:
                st.error(f"Could not load vehicle details: {error}")
    else:
        st.info("No catalogue vehicles match this budget and down payment.")

    st.subheader("Policy-based explanation")
    st.write(explanation["explanation"])

    with st.expander("Policy sources"):
        for source in explanation.get("sources", []):
            st.markdown(
                f"**{source.get('document_id')} — {source.get('section')}**"
            )
            st.write(source.get("text", ""))
