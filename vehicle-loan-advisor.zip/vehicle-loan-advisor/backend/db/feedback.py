﻿import sqlite3
from datetime import datetime, timezone

from backend.db.audit import DB_PATH


def save_feedback(
    rating: int,
    comment: str | None = None,
    audit_id: int | None = None,
) -> int:
    """Save a 1–5 rating and optional comment."""

    DB_PATH.parent.mkdir(parents=True, exist_ok=True)

    with sqlite3.connect(DB_PATH) as connection:
        connection.execute(
            """
            CREATE TABLE IF NOT EXISTS feedback (
                feedback_id INTEGER PRIMARY KEY AUTOINCREMENT,
                audit_id INTEGER,
                rating INTEGER NOT NULL CHECK (rating BETWEEN 1 AND 5),
                comment TEXT,
                created_at TEXT NOT NULL
            )
            """
        )
        cursor = connection.execute(
            """
            INSERT INTO feedback (audit_id, rating, comment, created_at)
            VALUES (?, ?, ?, ?)
            """,
            (
                audit_id,
                rating,
                comment,
                datetime.now(timezone.utc).isoformat(),
            ),
        )
        return int(cursor.lastrowid)
