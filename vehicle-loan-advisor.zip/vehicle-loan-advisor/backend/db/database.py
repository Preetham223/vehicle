﻿"""SQLite storage for the fictional vehicle catalogue."""

import json
import sqlite3
from pathlib import Path


PROJECT_ROOT = Path(__file__).resolve().parents[2]
DATABASE_PATH = PROJECT_ROOT / "data" / "vehicle_advisor.db"
CATALOGUE_PATH = PROJECT_ROOT / "data" / "raw" / "vehicle_catalogue.json"


def get_connection() -> sqlite3.Connection:
    DATABASE_PATH.parent.mkdir(parents=True, exist_ok=True)
    connection = sqlite3.connect(DATABASE_PATH, timeout=30)
    connection.row_factory = sqlite3.Row
    return connection


def initialize_database() -> int:
    """Validate and import the catalogue in one transaction."""
    if not CATALOGUE_PATH.exists():
        raise FileNotFoundError(
            f"Catalogue not found: {CATALOGUE_PATH}. "
            "Run python scripts/generate_vehicle_catalogue.py first."
        )

    vehicles = json.loads(CATALOGUE_PATH.read_text(encoding="utf-8"))
    if not isinstance(vehicles, list) or len(vehicles) < 25:
        raise ValueError("The catalogue must contain at least 25 vehicles.")

    records = []
    seen_ids = set()

    for vehicle in vehicles:
        vehicle_id = vehicle["vehicle_id"]
        if vehicle_id in seen_ids:
            raise ValueError(f"Duplicate vehicle ID: {vehicle_id}")
        seen_ids.add(vehicle_id)

        variants = vehicle["variants"]
        if not variants:
            raise ValueError(f"Vehicle {vehicle_id} has no variants.")

        for variant in variants:
            price = variant["on_road_price_inr"]
            if price <= 0:
                raise ValueError(f"Invalid price for {variant['variant_id']}")

        records.append((
            vehicle_id,
            vehicle["model"],
            vehicle["body_type"],
            vehicle["fuel_type"],
            min(v["on_road_price_inr"] for v in variants),
            json.dumps(vehicle, ensure_ascii=False),
        ))

    connection = get_connection()
    try:
        with connection:
            connection.execute("""
                CREATE TABLE IF NOT EXISTS vehicles (
                    vehicle_id TEXT PRIMARY KEY,
                    model TEXT NOT NULL,
                    body_type TEXT NOT NULL,
                    fuel_type TEXT NOT NULL,
                    minimum_on_road_price_inr INTEGER NOT NULL
                        CHECK (minimum_on_road_price_inr > 0),
                    catalogue_json TEXT NOT NULL
                )
            """)
            connection.executemany("""
                INSERT INTO vehicles (
                    vehicle_id, model, body_type, fuel_type,
                    minimum_on_road_price_inr, catalogue_json
                )
                VALUES (?, ?, ?, ?, ?, ?)
                ON CONFLICT(vehicle_id) DO UPDATE SET
                    model = excluded.model,
                    body_type = excluded.body_type,
                    fuel_type = excluded.fuel_type,
                    minimum_on_road_price_inr =
                        excluded.minimum_on_road_price_inr,
                    catalogue_json = excluded.catalogue_json
            """, records)
        return len(records)
    finally:
        connection.close()


def list_vehicles() -> list[dict]:
    """Return catalogue records ordered by starting on-road price."""
    connection = get_connection()
    try:
        rows = connection.execute("""
            SELECT catalogue_json FROM vehicles
            ORDER BY minimum_on_road_price_inr, vehicle_id
        """).fetchall()
        return [json.loads(row["catalogue_json"]) for row in rows]
    finally:
        connection.close()


def get_vehicle(vehicle_id: str) -> dict | None:
    """Return one vehicle, or None when its ID does not exist."""
    connection = get_connection()
    try:
        row = connection.execute(
            "SELECT catalogue_json FROM vehicles WHERE vehicle_id = ?",
            (vehicle_id,),
        ).fetchone()
        return json.loads(row["catalogue_json"]) if row else None
    finally:
        connection.close()


if __name__ == "__main__":
    imported = initialize_database()
    print(f"Imported vehicle models: {imported}")
    print(f"Stored vehicle models: {len(list_vehicles())}")
    print(f"Database saved to: {DATABASE_PATH}")
