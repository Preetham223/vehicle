﻿from fastapi import FastAPI, HTTPException
from openai import OpenAIError
from pydantic import BaseModel, Field

from backend.schemas import Applicant
from backend.services.advisor import run_advisor
from backend.services.eligibility import predict_eligibility
from backend.services.explain import explain_decision
from backend.services.loan_amount import calculate_sanctioned_amount
from backend.services.vehicles import (
    get_vehicle_details,
    list_affordable_vehicles,
)


app = FastAPI(
    title="Intelligent Vehicle Loan Advisor API",
    version="1.0.0",
)


class ExplainRequest(BaseModel):
    applicant: Applicant
    approved: bool
    sanctioned_amount_inr: float | None = Field(default=None, ge=0)
    language: str = "English"


class VehicleSearchRequest(BaseModel):
    applicant: Applicant


class ApplicationRequest(BaseModel):
    applicant: Applicant
    language: str = "English"


@app.get("/health")
def health():
    return {"status": "ok"}


@app.post("/predict")
def predict(applicant: Applicant):
    try:
        return predict_eligibility(applicant)
    except FileNotFoundError as error:
        raise HTTPException(status_code=503, detail=str(error)) from error


@app.post("/loan-amount")
def loan_amount(applicant: Applicant):
    eligibility = predict_eligibility(applicant)
    if eligibility["decision"] != "Approved":
        raise HTTPException(
            status_code=409,
            detail={
                "message": "Loan amount is available only after approval.",
                "eligibility": eligibility,
            },
        )
    try:
        return calculate_sanctioned_amount(applicant)
    except ValueError as error:
        raise HTTPException(status_code=409, detail=str(error)) from error


@app.post("/vehicles")
def affordable_vehicles(request: VehicleSearchRequest):
    eligibility = predict_eligibility(request.applicant)
    if eligibility["decision"] != "Approved":
        raise HTTPException(status_code=409, detail="Applicant is not approved.")

    loan = calculate_sanctioned_amount(request.applicant)
    vehicles = list_affordable_vehicles(
        request.applicant,
        loan["sanctioned_amount_inr"],
    )
    return {
        "sanctioned_amount_inr": loan["sanctioned_amount_inr"],
        "vehicles": vehicles,
    }


@app.get("/vehicles/{vehicle_id}")
def vehicle_details(vehicle_id: str):
    variants = get_vehicle_details(vehicle_id)
    if not variants:
        raise HTTPException(status_code=404, detail="Vehicle not found.")
    return {"vehicle_id": vehicle_id, "variants": variants}


@app.post("/explain")
def explain(request: ExplainRequest):
    try:
        return explain_decision(
            applicant=request.applicant,
            approved=request.approved,
            sanctioned_amount_inr=request.sanctioned_amount_inr,
            language=request.language,
        )
    except (FileNotFoundError, ValueError) as error:
        raise HTTPException(status_code=503, detail=str(error)) from error
    except OpenAIError as error:
        raise HTTPException(
            status_code=502,
            detail="The explanation service could not reach OpenAI.",
        ) from error


@app.post("/application")
def application(request: ApplicationRequest):
    try:
        return run_advisor(
            applicant=request.applicant,
            language=request.language,
        )
    except (FileNotFoundError, ValueError) as error:
        raise HTTPException(status_code=503, detail=str(error)) from error
    except OpenAIError as error:
        raise HTTPException(
            status_code=502,
            detail="The explanation service could not reach OpenAI.",
        ) from error
