﻿"""Build a local vector index using OpenAI embeddings."""

import hashlib
import json
import os
from pathlib import Path

import numpy as np
from dotenv import load_dotenv
from openai import OpenAI, APIStatusError


PROJECT_ROOT = Path(__file__).resolve().parents[2]
CHUNKS_PATH = PROJECT_ROOT / "data" / "processed" / "document_chunks.json"
INDEX_DIR = PROJECT_ROOT / "vectorstore"
INDEX_PATH = INDEX_DIR / "document_index.npz"
CACHE_PATH = INDEX_DIR / "embedding_cache.json"
BATCH_SIZE = 16


def write_cache(cache: dict) -> None:
    temporary_path = CACHE_PATH.with_suffix(".tmp")
    temporary_path.write_text(
        json.dumps(cache), encoding="utf-8"
    )
    temporary_path.replace(CACHE_PATH)


def build_index() -> None:
    load_dotenv(
        PROJECT_ROOT / ".env",
        encoding="utf-8-sig",
        override=True,
    )

    key = os.getenv("OPENAI_API_KEY", "").strip()
    model = os.getenv(
        "OPENAI_EMBEDDING_MODEL", "text-embedding-3-small"
    )
    dimensions = int(os.getenv("EMBEDDING_DIMENSIONS", "768"))

    if not key:
        raise ValueError("OPENAI_API_KEY is missing.")
    if not CHUNKS_PATH.exists():
        raise FileNotFoundError(
            "Run python -m backend.rag.chunk_documents first."
        )

    chunks = json.loads(CHUNKS_PATH.read_text(encoding="utf-8"))
    if not chunks:
        raise ValueError("No document chunks are available.")
    if len({chunk["chunk_id"] for chunk in chunks}) != len(chunks):
        raise ValueError("Duplicate chunk IDs found.")

    INDEX_DIR.mkdir(parents=True, exist_ok=True)
    cache = (
        json.loads(CACHE_PATH.read_text(encoding="utf-8"))
        if CACHE_PATH.exists()
        else {}
    )

    cache_keys = []
    for chunk in chunks:
        text = chunk["retrieval_text"].strip()
        if not text:
            raise ValueError(f"Empty chunk: {chunk['chunk_id']}")

        fingerprint = json.dumps(
            ["openai", model, dimensions, text],
            ensure_ascii=False,
        )
        cache_keys.append(
            hashlib.sha256(fingerprint.encode("utf-8")).hexdigest()
        )

    missing = [
        index for index, cache_key in enumerate(cache_keys)
        if cache_key not in cache
    ]

    print(f"Document chunks: {len(chunks)}")
    print(f"Cached embeddings: {len(chunks) - len(missing)}")
    print(f"Embeddings to generate: {len(missing)}")

    with OpenAI(api_key=key, timeout=30.0, max_retries=2) as client:
        for start in range(0, len(missing), BATCH_SIZE):
            indices = missing[start:start + BATCH_SIZE]
            response = client.embeddings.create(
                model=model,
                input=[chunks[i]["retrieval_text"] for i in indices],
                dimensions=dimensions,
                encoding_format="float",
            )

            embeddings = sorted(response.data, key=lambda item: item.index)
            if [item.index for item in embeddings] != list(range(len(indices))):
                raise ValueError("Unexpected embedding response indices.")

            for index, embedding in zip(indices, embeddings):
                values = np.asarray(embedding.embedding, dtype=np.float32)
                if (
                    values.shape != (dimensions,)
                    or not np.isfinite(values).all()
                    or np.linalg.norm(values) == 0
                ):
                    raise ValueError("Invalid embedding returned by OpenAI.")
                cache[cache_keys[index]] = embedding.embedding

            write_cache(cache)
            print(
                f"New embeddings completed: "
                f"{min(start + BATCH_SIZE, len(missing))}/{len(missing)}"
            )

    vectors = np.asarray(
        [cache[cache_key] for cache_key in cache_keys],
        dtype=np.float32,
    )
    if vectors.shape != (len(chunks), dimensions):
        raise ValueError("Cached embedding dimensions do not match.")
    if not np.isfinite(vectors).all():
        raise ValueError("Non-finite embedding values found.")

    norms = np.linalg.norm(vectors, axis=1, keepdims=True)
    if np.any(norms == 0):
        raise ValueError("Zero-length embedding found.")
    vectors = vectors / norms

    # Save vectors and their aligned metadata together.
    temporary_path = INDEX_PATH.with_suffix(".tmp")
    with temporary_path.open("wb") as stream:
        np.savez_compressed(
            stream,
            vectors=vectors,
            metadata_json=np.array(
                json.dumps(chunks, ensure_ascii=False)
            ),
            provider=np.array("openai"),
            model=np.array(model),
            dimensions=np.array(dimensions),
            chunks_sha256=np.array(
                hashlib.sha256(CHUNKS_PATH.read_bytes()).hexdigest()
            ),
        )
    temporary_path.replace(INDEX_PATH)

    print("\nVector index created successfully")
    print("Vector matrix shape:", vectors.shape)
    print("Embedding model:", model)
    print("Index saved to:", INDEX_PATH)


if __name__ == "__main__":
    try:
        build_index()
    except APIStatusError as error:
        raise SystemExit(
            f"OpenAI returned HTTP {error.status_code}; code: {error.code}. "
            "Completed batches are cached. Resolve the error and rerun."
        )
