﻿"""Split policy and brochure documents into source-labelled chunks."""

import json
from pathlib import Path


PROJECT_ROOT = Path(__file__).resolve().parents[2]
DOCUMENT_ROOT = PROJECT_ROOT / "data" / "documents"
OUTPUT_PATH = PROJECT_ROOT / "data" / "processed" / "document_chunks.json"

CHUNK_WORDS = 180
OVERLAP_WORDS = 30


def split_words(text: str) -> list[str]:
    """Split long sections with overlap; never mix separate sections."""
    words = text.split()
    if not words:
        return []

    chunks = []
    start = 0
    while start < len(words):
        end = min(start + CHUNK_WORDS, len(words))
        chunks.append(" ".join(words[start:end]))
        if end == len(words):
            break
        start = end - OVERLAP_WORDS

    return chunks


def read_sections(path: Path) -> tuple[dict, list[tuple[str, str]]]:
    """Read document headers and the explicitly labelled sections."""
    metadata = {}
    sections = []
    current_section = None
    current_lines = []

    for line in path.read_text(encoding="utf-8-sig").splitlines():
        stripped = line.strip()

        if stripped.startswith("SECTION:"):
            if current_section is not None:
                sections.append((
                    current_section,
                    "\n".join(current_lines).strip(),
                ))
            current_section = stripped.split(":", 1)[1].strip()
            current_lines = []
        elif current_section is None:
            for label, key in [
                ("DOCUMENT ID:", "document_id"),
                ("TITLE:", "title"),
                ("VEHICLE ID:", "vehicle_id"),
                ("VERSION:", "version"),
            ]:
                if stripped.startswith(label):
                    metadata[key] = stripped[len(label):].strip()
                    break
        else:
            current_lines.append(line)

    if current_section is not None:
        sections.append((
            current_section,
            "\n".join(current_lines).strip(),
        ))

    if not metadata.get("document_id") or not metadata.get("title"):
        raise ValueError(f"Missing document ID or title: {path}")
    if not sections:
        raise ValueError(f"No labelled sections found: {path}")

    return metadata, sections


def build_chunks() -> list[dict]:
    paths = sorted(DOCUMENT_ROOT.rglob("*.txt"))
    if not paths:
        raise FileNotFoundError(f"No documents found in {DOCUMENT_ROOT}")

    records = []
    seen_document_ids = set()

    for path in paths:
        metadata, sections = read_sections(path)
        document_id = metadata["document_id"]

        if document_id in seen_document_ids:
            raise ValueError(f"Duplicate document ID: {document_id}")
        seen_document_ids.add(document_id)

        relative_path = path.relative_to(DOCUMENT_ROOT)
        document_type = relative_path.parts[0]
        if document_type not in {"policy", "vehicles"}:
            raise ValueError(f"Unknown document category: {relative_path}")

        for section_number, (section, text) in enumerate(sections, start=1):
            for chunk_number, chunk in enumerate(split_words(text), start=1):
                records.append({
                    "chunk_id": (
                        f"{document_id}-S{section_number:03d}"
                        f"-C{chunk_number:03d}"
                    ),
                    **metadata,
                    "document_type": document_type,
                    "source_path": relative_path.as_posix(),
                    "section": section,
                    "text": chunk,
                    "retrieval_text": (
                        f"{metadata['title']}\nSection: {section}\n{chunk}"
                    ),
                })

    OUTPUT_PATH.parent.mkdir(parents=True, exist_ok=True)
    OUTPUT_PATH.write_text(
        json.dumps(records, indent=2, ensure_ascii=False),
        encoding="utf-8",
    )

    print(f"Documents processed: {len(paths)}")
    print(f"Chunks created: {len(records)}")
    print(f"Policy chunks: {sum(r['document_type'] == 'policy' for r in records)}")
    print(f"Vehicle chunks: {sum(r['document_type'] == 'vehicles' for r in records)}")
    print(f"Saved to: {OUTPUT_PATH}")
    return records


if __name__ == "__main__":
    build_chunks()
