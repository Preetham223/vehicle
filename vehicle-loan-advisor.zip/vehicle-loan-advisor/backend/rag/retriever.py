﻿"""Source-labelled similarity search over the local OpenAI vector index."""

import hashlib
import json
import os
from functools import lru_cache
from pathlib import Path

import numpy as np
from dotenv import load_dotenv
from openai import OpenAI


PROJECT_ROOT = Path(__file__).resolve().parents[2]
INDEX_PATH = PROJECT_ROOT / "vectorstore" / "document_index.npz"
CHUNKS_PATH = PROJECT_ROOT / "data" / "processed" / "document_chunks.json"


@lru_cache(maxsize=1)
def _load_index(modified_ns: int, file_size: int) -> dict:
    """Cache the index; file changes cause it to be loaded again."""
    with np.load(INDEX_PATH, allow_pickle=False) as stored:
        index = {
            "vectors": stored["vectors"].copy(),
            "chunks": json.loads(str(stored["metadata_json"].item())),
            "provider": str(stored["provider"].item()),
            "model": str(stored["model"].item()),
            "dimensions": int(stored["dimensions"].item()),
            "chunks_sha256": str(stored["chunks_sha256"].item()),
        }

    vectors = index["vectors"]
    if vectors.shape != (len(index["chunks"]), index["dimensions"]):
        raise ValueError("Vector index and metadata do not match.")
    if not np.isfinite(vectors).all():
        raise ValueError("The index contains invalid vector values.")
    if not np.allclose(np.linalg.norm(vectors, axis=1), 1, atol=1e-5):
        raise ValueError("Index vectors must be normalized.")

    return index


def load_index() -> dict:
    if not INDEX_PATH.exists():
        raise FileNotFoundError(
            "Run python -m backend.rag.build_index first."
        )

    stat = INDEX_PATH.stat()
    index = _load_index(stat.st_mtime_ns, stat.st_size)

    if not CHUNKS_PATH.exists():
        raise FileNotFoundError("The source chunks file is missing.")
    current_hash = hashlib.sha256(CHUNKS_PATH.read_bytes()).hexdigest()
    if current_hash != index["chunks_sha256"]:
        raise ValueError(
            "Document chunks changed. Rebuild the vector index."
        )
    return index


def retrieve(
    query: str,
    document_type: str | None = None,
    vehicle_id: str | None = None,
    top_k: int = 5,
    min_similarity: float = 0.25,
) -> list[dict]:
    """Return relevant chunks, optionally restricted by document or vehicle."""
    query = query.strip()
    if not query:
        raise ValueError("The query cannot be empty.")
    if len(query) > 4000:
        raise ValueError("The query must be no longer than 4000 characters.")
    if document_type not in {None, "policy", "vehicles"}:
        raise ValueError("document_type must be 'policy' or 'vehicles'.")
    if vehicle_id and document_type == "policy":
        raise ValueError("A vehicle ID cannot be used with policy documents.")
    if not 1 <= top_k <= 20:
        raise ValueError("top_k must be between 1 and 20.")
    if not -1 <= min_similarity <= 1:
        raise ValueError("min_similarity must be between -1 and 1.")

    index = load_index()
    candidates = [
        position
        for position, chunk in enumerate(index["chunks"])
        if (document_type is None or chunk["document_type"] == document_type)
        and (vehicle_id is None or chunk.get("vehicle_id") == vehicle_id)
    ]
    if not candidates:
        return []

    load_dotenv(
        PROJECT_ROOT / ".env",
        encoding="utf-8-sig",
        override=True,
    )

    model = os.getenv(
        "OPENAI_EMBEDDING_MODEL", "text-embedding-3-small"
    )
    dimensions = int(os.getenv("EMBEDDING_DIMENSIONS", "768"))

    if (
        index["provider"] != "openai"
        or model != index["model"]
        or dimensions != index["dimensions"]
    ):
        raise ValueError(
            "Embedding settings differ from the saved index. "
            "Rebuild the index before searching."
        )

    with OpenAI(timeout=30.0, max_retries=2) as client:
        response = client.embeddings.create(
            model=model,
            input=query,
            dimensions=dimensions,
            encoding_format="float",
        )

    query_vector = np.asarray(
        response.data[0].embedding, dtype=np.float32
    )
    norm = np.linalg.norm(query_vector)
    if (
        query_vector.shape != (dimensions,)
        or not np.isfinite(query_vector).all()
        or norm == 0
    ):
        raise ValueError("Invalid query embedding returned.")

    query_vector /= norm
    similarities = index["vectors"][candidates] @ query_vector
    ranked = np.argsort(-similarities, kind="stable")

    matches = []
    for rank in ranked:
        similarity = float(similarities[rank])
        if similarity < min_similarity:
            continue

        chunk = index["chunks"][candidates[int(rank)]]
        matches.append({
            **chunk,
            "similarity": similarity,
        })
        if len(matches) == top_k:
            break

    return matches


def get_policy_section(section: str) -> list[dict]:
    """Fetch an exact policy section for a known rule or calculation."""
    return [
        dict(chunk)
        for chunk in load_index()["chunks"]
        if chunk["document_type"] == "policy"
        and chunk["section"] == section
    ]
