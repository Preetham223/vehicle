﻿from pathlib import Path

import joblib
import pandas as pd

from backend.services.policy import policy_violations

MODEL_PATH = Path(__file__).resolve().parents[2] / "models" / "eligibility_model.joblib"
_artifact = None


def _load_artifact():
    global _artifact

    if _artifact is None:
        if not MODEL_PATH.exists():
            raise FileNotFoundError(
                f"Eligibility model not found: {MODEL_PATH}. "
                "Run the model training script first."
            )
        _artifact = joblib.load(MODEL_PATH)

    return _artifact


def _applicant_dict(applicant):
    if isinstance(applicant, dict):
        return applicant
    if hasattr(applicant, "model_dump"):
        return applicant.model_dump()
    if hasattr(applicant, "dict"):
        return applicant.dict()
    return vars(applicant)


def predict_eligibility(applicant):
    artifact = _load_artifact()

    # The training script saves a dictionary containing the model and metadata.
    # Keep support for a plain model artifact as well.
    if isinstance(artifact, dict) and "model" in artifact:
        model = artifact["model"]
        features = artifact.get("features", [])
        threshold = float(artifact.get("threshold", 0.5))
        target_mapping = artifact.get(
            "target_mapping",
            {"rejected": 0, "approved": 1},
        )
        selected_model = artifact.get("selected_model")
    else:
        model = artifact
        features = []
        threshold = 0.5
        target_mapping = {"rejected": 0, "approved": 1}
        selected_model = None

    applicant_values = _applicant_dict(applicant)
    if not features:
        features = list(applicant_values.keys())

    missing = [name for name in features if name not in applicant_values]
    if missing:
        raise ValueError(
            "Applicant data is missing model features: " + ", ".join(missing)
        )

    row = pd.DataFrame(
        [{name: applicant_values[name] for name in features}],
        columns=features,
    )

    approved_probability = None
    if hasattr(model, "predict_proba"):
        probabilities = model.predict_proba(row)[0]
        classes = list(getattr(model, "classes_", range(len(probabilities))))

        approved_class = target_mapping.get("approved", 1)
        try:
            approved_index = classes.index(approved_class)
        except ValueError:
            approved_index = 1

        approved_probability = float(probabilities[approved_index])
        model_approved = approved_probability >= threshold
    else:
        raw_prediction = model.predict(row)[0]
        reverse_mapping = {value: key for key, value in target_mapping.items()}
        model_approved = reverse_mapping.get(raw_prediction, raw_prediction) in (
            "approved",
            True,
            1,
        )

    violations = policy_violations(applicant)
    decision = "approved" if model_approved and not violations else "rejected"

    return {
        "decision": decision,
        "model_decision": "approved" if model_approved else "rejected",
        "approved_probability": approved_probability,
        "threshold": threshold,
        "policy_violations": violations,
        "selected_model": selected_model,
    }
