﻿from pathlib import Path

import pandas as pd

from backend.schemas import Applicant
from backend.services.policy import (
    ANNUAL_INTEREST_RATE,
    MAX_LOAN_TO_VALUE_RATIO,
    calculate_emi,
)


PROJECT_ROOT = Path(__file__).resolve().parents[2]
CATALOG_PATH = PROJECT_ROOT / "data" / "raw" / "vehicle_catalog.csv"

REQUIRED_COLUMNS = {
    "vehicle_id",
    "vehicle_name",
    "variant_id",
    "variant_name",
    "on_road_price_inr",
    "features",
}


def _load_catalog() -> pd.DataFrame:
    if not CATALOG_PATH.is_file():
        raise FileNotFoundError(f"Vehicle catalogue not found: {CATALOG_PATH}")

    catalog = pd.read_csv(CATALOG_PATH)
    missing = REQUIRED_COLUMNS - set(catalog.columns)
    if missing:
        raise ValueError(f"Vehicle catalogue is missing: {sorted(missing)}")
    return catalog


def _plain_value(value):
    if pd.isna(value):
        return None
    if hasattr(value, "item"):
        return value.item()
    return value


def list_affordable_vehicles(
    applicant: Applicant,
    sanctioned_amount_inr: float,
) -> list[dict]:
    catalog = _load_catalog()
    results = []

    for _, row in catalog.iterrows():
        price = float(row["on_road_price_inr"])
        required_loan = max(0.0, price - applicant.down_payment_inr)

        if required_loan > sanctioned_amount_inr:
            continue
        if required_loan > price * MAX_LOAN_TO_VALUE_RATIO:
            continue

        vehicle = {key: _plain_value(value) for key, value in row.to_dict().items()}
        vehicle["on_road_price_inr"] = price
        vehicle["estimated_loan_inr"] = round(required_loan, 2)
        vehicle["estimated_emi_inr"] = round(
            calculate_emi(
                required_loan,
                ANNUAL_INTEREST_RATE,
                applicant.requested_tenure_months,
            ),
            2,
        )
        results.append(vehicle)

    return results


def get_vehicle_details(vehicle_id: str) -> list[dict]:
    catalog = _load_catalog()
    matches = catalog[catalog["vehicle_id"].astype(str) == vehicle_id]
    return [
        {key: _plain_value(value) for key, value in row.items()}
        for row in matches.to_dict(orient="records")
    ]
