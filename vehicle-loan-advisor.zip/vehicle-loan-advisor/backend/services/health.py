﻿import os
from pathlib import Path

from dotenv import load_dotenv

from backend.services.eligibility import MODEL_PATH
from backend.services.vehicles import CATALOG_PATH


PROJECT_ROOT = Path(__file__).resolve().parents[2]
VECTORSTORE_DIR = PROJECT_ROOT / "vectorstore"


def get_readiness() -> dict:
    load_dotenv(encoding="utf-8-sig", override=True)

    checks = {
        "openai_api_key_configured": bool(
            os.getenv("OPENAI_API_KEY", "").strip()
        ),
        "eligibility_model_found": MODEL_PATH.is_file(),
        "vehicle_catalog_found": CATALOG_PATH.is_file(),
        "vectorstore_files_found": (
            VECTORSTORE_DIR.is_dir()
            and any(VECTORSTORE_DIR.iterdir())
        ),
    }

    return {
        "status": "ready" if all(checks.values()) else "not_ready",
        "checks": checks,
    }
