﻿from io import BytesIO
from xml.sax.saxutils import escape

from reportlab.lib.pagesizes import letter
from reportlab.lib.styles import getSampleStyleSheet
from reportlab.platypus import Paragraph, SimpleDocTemplate, Spacer


def build_decision_pdf(report: dict) -> bytes:
    output = BytesIO()
    document = SimpleDocTemplate(output, pagesize=letter)
    styles = getSampleStyleSheet()
    story = [
        Paragraph("Vehicle Loan Decision Report", styles["Title"]),
        Spacer(1, 16),
        Paragraph(f"Decision: {escape(report['decision'])}", styles["Heading2"]),
        Paragraph(
            f"Model prediction: {escape(report['model_decision'])}",
            styles["BodyText"],
        ),
        Spacer(1, 12),
    ]

    amount = report.get("sanctioned_amount_inr")
    if amount is not None:
        story.append(
            Paragraph(f"Estimated sanctioned amount: INR {amount:,.0f}", styles["BodyText"])
        )

    emi = report.get("monthly_emi_inr")
    if emi is not None:
        story.append(
            Paragraph(f"Estimated monthly EMI: INR {emi:,.0f}", styles["BodyText"])
        )

    story.extend([
        Spacer(1, 16),
        Paragraph("Explanation", styles["Heading2"]),
        Paragraph(escape(report["explanation"]), styles["BodyText"]),
        Spacer(1, 16),
        Paragraph("Policy sources", styles["Heading2"]),
    ])

    for source in report.get("sources", []):
        label = (
            f"{source.get('document_id', 'Unknown document')} | "
            f"{source.get('section', 'Unknown section')}"
        )
        story.append(Paragraph(escape(label), styles["Heading3"]))
        if source.get("text"):
            story.append(Paragraph(escape(source["text"]), styles["BodyText"]))
        story.append(Spacer(1, 8))

    document.build(story)
    return output.getvalue()
