﻿from backend.schemas import Applicant
from backend.services.eligibility import predict_eligibility
from backend.services.explain import explain_decision
from backend.services.loan_amount import calculate_sanctioned_amount
from backend.services.vehicles import list_affordable_vehicles


def run_advisor(applicant: Applicant, language: str = "English") -> dict:
    eligibility = predict_eligibility(applicant)
    loan = None
    vehicles = []

    approved = eligibility["decision"] == "Approved"
    if approved:
        loan = calculate_sanctioned_amount(applicant)
        vehicles = list_affordable_vehicles(
            applicant,
            loan["sanctioned_amount_inr"],
        )

    explanation = explain_decision(
        applicant=applicant,
        approved=approved,
        sanctioned_amount_inr=(
            loan["sanctioned_amount_inr"] if loan else None
        ),
        language=language,
    )

    return {
        "eligibility": eligibility,
        "loan": loan,
        "vehicles": vehicles,
        "explanation": explanation,
    }
