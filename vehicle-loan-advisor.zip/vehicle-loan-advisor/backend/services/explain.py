﻿import os
from pathlib import Path

from dotenv import load_dotenv
from openai import OpenAI

from backend.rag.retriever import get_policy_section, retrieve
from backend.schemas import Applicant
from backend.services.policy import policy_violations


PROJECT_ROOT = Path(__file__).resolve().parents[2]


def explain_decision(
    applicant: Applicant,
    approved: bool,
    sanctioned_amount_inr: float | None = None,
    language: str = "English",
) -> dict:
    load_dotenv(PROJECT_ROOT / ".env", encoding="utf-8-sig", override=False)
    api_key = os.getenv("OPENAI_API_KEY", "").strip()
    if not api_key:
        raise ValueError("OPENAI_API_KEY is missing.")

    violations = policy_violations(applicant)

    if not approved and violations:
        passages = []
        for violation in violations:
            passages.extend(get_policy_section(violation.section))
    else:
        passages = retrieve(
            "Vehicle loan eligibility and sanctioned loan amount policy rules",
            document_type="policy",
            top_k=8,
            min_similarity=0.25,
        )

    unique = []
    seen = set()
    for item in passages:
        key = (item.get("document_id"), item.get("section"))
        if key not in seen:
            unique.append(item)
            seen.add(key)
    passages = unique

    sources = [
        {
            "document_id": item.get("document_id"),
            "section": item.get("section"),
            "text": item.get("text"),
        }
        for item in passages
    ]

    if not sources:
        return {
            "explanation": (
                "The indexed policy documents do not contain enough information "
                "to explain this decision."
            ),
            "sources": [],
        }

    policy_text = "\n\n".join(
        f"[{s['document_id']} | {s['section']}]\n{s['text']}" for s in sources
    )
    failed_rules = "\n".join(
        f"- {item.message} (section: {item.section})"
        for item in violations
    ) or "No failed policy rule was returned."

    amount = (
        f"INR {sanctioned_amount_inr:,.0f}"
        if sanctioned_amount_inr is not None
        else "not provided"
    )

    prompt = f"""
Explain this vehicle loan decision in {language}.

Use only the applicant facts and policy passages below. Do not invent rules,
thresholds, calculations, or sources. If the passages do not support a detail,
say that the policy documents do not provide it. Do not change the decision.
Cite sources as [document_id | section].

Decision: {"Approved" if approved else "Rejected"}
Sanctioned amount: {amount}

Applicant facts:
Age: {applicant.age}
Monthly income: INR {applicant.monthly_income_inr:,.0f}
Credit score: {applicant.credit_score}
Existing monthly EMIs: INR {applicant.existing_emi_inr:,.0f}
Employment type: {applicant.employment_type}
Employment experience: {applicant.employment_years} years
Current employment: {applicant.current_employment_months} months
Requested tenure: {applicant.requested_tenure_months} months

Policy checks:
{failed_rules}

Retrieved policy passages:
{policy_text}
"""

    client = OpenAI(api_key=api_key)
    try:
        response = client.chat.completions.create(
            model=os.getenv("OPENAI_CHAT_MODEL", "gpt-4.1-mini"),
            messages=[
                {
                    "role": "developer",
                    "content": (
                        "Write concise explanations grounded only in the "
                        "provided policy passages."
                    ),
                },
                {"role": "user", "content": prompt},
            ],
            temperature=0.2,
        )
        explanation = (response.choices[0].message.content or "").strip()
    finally:
        client.close()

    return {
        "explanation": explanation or "No explanation was returned.",
        "sources": sources,
    }
