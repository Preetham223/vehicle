﻿"""Sample policy rules for the vehicle loan advisor capstone.

These thresholds are fictional project assumptions, not rules from a real lender.
"""

from dataclasses import dataclass

from backend.schemas import Applicant


MIN_CREDIT_SCORE = 650
MIN_MONTHLY_INCOME_INR = 25_000
MAX_FIXED_OBLIGATION_RATIO = 0.50
MAX_AGE_AT_LOAN_END = 70
MIN_SALARIED_JOB_MONTHS = 6
MIN_SELF_EMPLOYED_EXPERIENCE_YEARS = 2

MAX_LOAN_TO_VALUE_RATIO = 0.90
MAX_LOAN_AMOUNT_INR = 2_500_000
ANNUAL_INTEREST_RATE = 0.12


@dataclass(frozen=True)
class PolicyViolation:
    code: str
    section: str
    message: str


def policy_violations(applicant: Applicant) -> list[PolicyViolation]:
    """Return the sample policy rules the applicant does not satisfy."""
    violations = []

    if applicant.credit_score < MIN_CREDIT_SCORE:
        violations.append(
            PolicyViolation(
                code="ELIG-001",
                section="Eligibility - Credit Score",
                message=(
                    f"Credit score {applicant.credit_score} is below the "
                    f"minimum of {MIN_CREDIT_SCORE}."
                ),
            )
        )

    if applicant.monthly_income_inr < MIN_MONTHLY_INCOME_INR:
        violations.append(
            PolicyViolation(
                code="ELIG-002",
                section="Eligibility - Minimum Income",
                message=(
                    f"Monthly income ₹{applicant.monthly_income_inr:,.0f} is below "
                    f"the minimum of ₹{MIN_MONTHLY_INCOME_INR:,.0f}."
                ),
            )
        )

    obligation_ratio = (
        applicant.existing_emi_inr / applicant.monthly_income_inr
    )
    if obligation_ratio > MAX_FIXED_OBLIGATION_RATIO:
        violations.append(
            PolicyViolation(
                code="ELIG-003",
                section="Eligibility - Existing Obligations",
                message=(
                    f"Existing EMIs use {obligation_ratio:.1%} of monthly income; "
                    f"the policy limit is {MAX_FIXED_OBLIGATION_RATIO:.0%}."
                ),
            )
        )

    if applicant.age + applicant.requested_tenure_months / 12 > MAX_AGE_AT_LOAN_END:
        violations.append(
            PolicyViolation(
                code="ELIG-004",
                section="Eligibility - Age at Loan Maturity",
                message=(
                    f"Applicant age at the end of the requested tenure would exceed "
                    f"{MAX_AGE_AT_LOAN_END}."
                ),
            )
        )

    if (
        applicant.employment_type == "salaried"
        and applicant.current_employment_months < MIN_SALARIED_JOB_MONTHS
    ):
        violations.append(
            PolicyViolation(
                code="ELIG-005",
                section="Eligibility - Salaried Employment Stability",
                message=(
                    f"Current employment is {applicant.current_employment_months} "
                    f"months; the policy requires at least "
                    f"{MIN_SALARIED_JOB_MONTHS} months."
                ),
            )
        )

    if (
        applicant.employment_type == "self_employed"
        and applicant.employment_years < MIN_SELF_EMPLOYED_EXPERIENCE_YEARS
    ):
        violations.append(
            PolicyViolation(
                code="ELIG-006",
                section="Eligibility - Self-Employed Experience",
                message=(
                    f"Self-employment experience is {applicant.employment_years} "
                    f"years; the policy requires at least "
                    f"{MIN_SELF_EMPLOYED_EXPERIENCE_YEARS} years."
                ),
            )
        )

    return violations


def maximum_affordable_emi_inr(applicant: Applicant) -> float:
    """Calculate remaining EMI capacity under the fixed-obligation limit."""
    allowed_total_emi = (
        applicant.monthly_income_inr * MAX_FIXED_OBLIGATION_RATIO
    )
    return max(0.0, allowed_total_emi - applicant.existing_emi_inr)


def calculate_emi(
    principal_inr: float,
    annual_interest_rate: float,
    tenure_months: int,
) -> float:
    """Calculate monthly EMI using the standard reducing-balance formula."""
    if principal_inr <= 0:
        return 0.0
    if tenure_months <= 0:
        raise ValueError("Tenure must be greater than zero.")

    monthly_rate = annual_interest_rate / 12
    if monthly_rate == 0:
        return principal_inr / tenure_months

    factor = (1 + monthly_rate) ** tenure_months
    return principal_inr * monthly_rate * factor / (factor - 1)


def maximum_principal_for_emi(
    monthly_emi_inr: float,
    annual_interest_rate: float,
    tenure_months: int,
) -> float:
    """Calculate the principal supported by a monthly EMI limit."""
    if monthly_emi_inr <= 0:
        return 0.0
    if tenure_months <= 0:
        raise ValueError("Tenure must be greater than zero.")

    monthly_rate = annual_interest_rate / 12
    if monthly_rate == 0:
        return monthly_emi_inr * tenure_months

    factor = (1 + monthly_rate) ** tenure_months
    return monthly_emi_inr * (factor - 1) / (monthly_rate * factor)
