﻿from backend.schemas import Applicant
from backend.services.policy import (
    ANNUAL_INTEREST_RATE,
    MAX_LOAN_AMOUNT_INR,
    calculate_emi,
    maximum_affordable_emi_inr,
    maximum_principal_for_emi,
    policy_violations,
)


def calculate_sanctioned_amount(applicant: Applicant) -> dict:
    violations = policy_violations(applicant)
    if violations:
        raise ValueError("Applicant fails mandatory policy rules.")

    max_emi = maximum_affordable_emi_inr(applicant)
    affordable_principal = maximum_principal_for_emi(
        max_emi,
        ANNUAL_INTEREST_RATE,
        applicant.requested_tenure_months,
    )
    amount = float(int(min(affordable_principal, MAX_LOAN_AMOUNT_INR)))

    return {
        "sanctioned_amount_inr": amount,
        "monthly_emi_inr": round(
            calculate_emi(
                amount,
                ANNUAL_INTEREST_RATE,
                applicant.requested_tenure_months,
            ),
            2,
        ),
        "annual_interest_rate": ANNUAL_INTEREST_RATE,
        "tenure_months": applicant.requested_tenure_months,
        "maximum_affordable_emi_inr": round(max_emi, 2),
    }
