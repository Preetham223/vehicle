﻿from typing import Literal

from pydantic import BaseModel, ConfigDict, Field, model_validator


class Applicant(BaseModel):
    model_config = ConfigDict(extra="forbid")

    age: int = Field(ge=18, le=75)
    monthly_income_inr: float = Field(gt=0, le=10_000_000)
    credit_score: int = Field(ge=300, le=900)
    employment_years: float = Field(ge=0, le=60)
    current_employment_months: int = Field(ge=0, le=720)
    employment_type: Literal["salaried", "self_employed"]
    dependents: int = Field(default=0, ge=0, le=20)
    residence_type: Literal["owned", "rented"] = "owned"
    existing_emi_inr: float = Field(ge=0, le=10_000_000)
    requested_tenure_months: int = Field(ge=12, le=84)
    down_payment_inr: float = Field(ge=0, le=100_000_000)

    @model_validator(mode="after")
    def employment_months_cannot_exceed_experience(self):
        if self.current_employment_months > self.employment_years * 12:
            raise ValueError(
                "Current employment months cannot exceed total employment experience."
            )
        return self


class Prediction(Applicant):
    pass


class LoanAmountRequest(Applicant):
    vehicle_id: str
    application_id: str | None = None
