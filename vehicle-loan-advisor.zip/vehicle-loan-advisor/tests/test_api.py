﻿import backend.main as main
from fastapi.testclient import TestClient


client = TestClient(main.app)


def test_health_endpoint():
    response = client.get("/health")
    assert response.status_code == 200
    assert response.json()["status"] == "ok"


def test_predict_endpoint_uses_eligibility_service(monkeypatch):
    monkeypatch.setattr(
        main,
        "predict_eligibility",
        lambda applicant: {
            "decision": "Approved",
            "model_decision": "Approved",
            "approved_probability": 0.91,
            "policy_violations": [],
        },
    )

    response = client.post(
        "/predict",
        json={
            "age": 35,
            "monthly_income_inr": 60000,
            "credit_score": 720,
            "employment_years": 5,
            "current_employment_months": 24,
            "employment_type": "salaried",
            "dependents": 1,
            "residence_type": "owned",
            "existing_emi_inr": 10000,
            "requested_tenure_months": 60,
            "down_payment_inr": 100000,
        },
    )

    assert response.status_code == 200
    assert response.json()["decision"] == "Approved"


def test_explain_endpoint_returns_sources(monkeypatch):
    monkeypatch.setattr(
        main,
        "explain_decision",
        lambda **kwargs: {
            "explanation": "The decision follows the supplied policy.",
            "sources": [
                {
                    "document_id": "VLP-001",
                    "section": "Eligibility - Credit Score",
                    "text": "Sample policy passage",
                }
            ],
        },
    )

    response = client.post(
        "/explain",
        json={
            "applicant": {
                "age": 35,
                "monthly_income_inr": 60000,
                "credit_score": 620,
                "employment_years": 5,
                "current_employment_months": 24,
                "employment_type": "salaried",
                "dependents": 1,
                "residence_type": "owned",
                "existing_emi_inr": 35000,
                "requested_tenure_months": 60,
                "down_payment_inr": 100000,
            },
            "approved": False,
            "language": "English",
        },
    )

    assert response.status_code == 200
    assert response.json()["sources"][0]["document_id"] == "VLP-001"
