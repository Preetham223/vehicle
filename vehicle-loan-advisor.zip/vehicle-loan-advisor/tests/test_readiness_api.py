﻿import backend.main as main
from fastapi.testclient import TestClient


client = TestClient(main.app)


def test_ready_endpoint_returns_readiness(monkeypatch):
    monkeypatch.setattr(
        main,
        "get_readiness",
        lambda: {
            "status": "ready",
            "checks": {
                "openai_api_key_configured": True,
                "eligibility_model_found": True,
                "vehicle_catalog_found": True,
                "vectorstore_files_found": True,
            },
        },
    )

    response = client.get("/ready")

    assert response.status_code == 200
    assert response.json()["status"] == "ready"
