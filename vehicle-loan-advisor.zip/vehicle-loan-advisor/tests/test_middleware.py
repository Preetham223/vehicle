﻿import backend.main as main
from fastapi.testclient import TestClient


client = TestClient(main.app)


def test_request_id_is_returned():
    response = client.get(
        "/health",
        headers={"X-Request-ID": "demo-request-123"},
    )

    assert response.status_code == 200
    assert response.headers["X-Request-ID"] == "demo-request-123"
