﻿import pytest

from backend.schemas import Applicant
from backend.services.loan_amount import calculate_sanctioned_amount
from backend.services.policy import (
    MAX_LOAN_AMOUNT_INR,
    maximum_affordable_emi_inr,
)


def make_applicant(**overrides):
    values = {
        "age": 35,
        "monthly_income_inr": 60000,
        "credit_score": 720,
        "employment_years": 5,
        "current_employment_months": 24,
        "employment_type": "salaried",
        "dependents": 1,
        "residence_type": "owned",
        "existing_emi_inr": 10000,
        "requested_tenure_months": 60,
        "down_payment_inr": 100000,
    }
    values.update(overrides)
    return Applicant(**values)


def test_sanctioned_amount_respects_cap_and_emi_capacity():
    applicant = make_applicant()
    result = calculate_sanctioned_amount(applicant)

    assert result["sanctioned_amount_inr"] <= MAX_LOAN_AMOUNT_INR
    assert result["monthly_emi_inr"] <= maximum_affordable_emi_inr(applicant)
    assert result["tenure_months"] == applicant.requested_tenure_months


def test_ineligible_applicant_cannot_get_sanctioned_amount():
    applicant = make_applicant(credit_score=620)

    with pytest.raises(ValueError):
        calculate_sanctioned_amount(applicant)
