﻿from backend.services import health


def test_readiness_reports_all_required_assets(monkeypatch, tmp_path):
    model = tmp_path / "eligibility_model.joblib"
    catalog = tmp_path / "vehicle_catalog.csv"
    vectorstore = tmp_path / "vectorstore"

    model.write_bytes(b"model")
    catalog.write_text("vehicle_id\nVEH-001\n", encoding="utf-8")
    vectorstore.mkdir()
    (vectorstore / "index.bin").write_bytes(b"index")

    monkeypatch.setattr(health, "MODEL_PATH", model)
    monkeypatch.setattr(health, "CATALOG_PATH", catalog)
    monkeypatch.setattr(health, "VECTORSTORE_DIR", vectorstore)
    monkeypatch.setattr(health, "load_dotenv", lambda **kwargs: None)
    monkeypatch.setenv("OPENAI_API_KEY", "test-key")

    result = health.get_readiness()

    assert result["status"] == "ready"
    assert all(result["checks"].values())
