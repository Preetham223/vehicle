﻿import numpy as np

from backend.schemas import Applicant
from backend.services import eligibility


def make_applicant(**overrides):
    values = {
        "age": 35,
        "monthly_income_inr": 60000,
        "credit_score": 720,
        "employment_years": 5,
        "current_employment_months": 24,
        "employment_type": "salaried",
        "dependents": 1,
        "residence_type": "owned",
        "existing_emi_inr": 10000,
        "requested_tenure_months": 60,
        "down_payment_inr": 100000,
    }
    values.update(overrides)
    return Applicant(**values)


class FakeModel:
    classes_ = ["Rejected", "Approved"]

    def predict(self, data):
        return np.array(["Approved"])

    def predict_proba(self, data):
        return np.array([[0.2, 0.8]])


def test_eligible_model_prediction_is_approved(monkeypatch):
    monkeypatch.setattr(eligibility, "load_eligibility_model", FakeModel)

    result = eligibility.predict_eligibility(make_applicant())

    assert result["decision"] == "Approved"
    assert result["model_decision"] == "Approved"
    assert result["approved_probability"] == 0.8
    assert result["policy_violations"] == []


def test_policy_failure_overrides_model_approval(monkeypatch):
    monkeypatch.setattr(eligibility, "load_eligibility_model", FakeModel)

    result = eligibility.predict_eligibility(
        make_applicant(credit_score=620)
    )

    assert result["model_decision"] == "Approved"
    assert result["decision"] == "Rejected"
    assert any(
        item["code"] == "ELIG-001"
        for item in result["policy_violations"]
    )
