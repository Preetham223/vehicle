﻿import sqlite3

from backend.services import feedback


def test_save_feedback_persists_rating_and_audit_id(monkeypatch, tmp_path):
    test_db = tmp_path / "feedback.db"
    monkeypatch.setattr(feedback, "DB_PATH", test_db)

    feedback_id = feedback.save_feedback(
        audit_id=12,
        rating=5,
        comment="The explanation was clear.",
    )

    assert feedback_id == 1

    with sqlite3.connect(test_db) as connection:
        row = connection.execute(
            """
            SELECT audit_id, rating, comment
            FROM feedback
            WHERE feedback_id = ?
            """,
            (feedback_id,),
        ).fetchone()

    assert row == (12, 5, "The explanation was clear.")
