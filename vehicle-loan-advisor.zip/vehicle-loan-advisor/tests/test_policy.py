﻿from backend.schemas import Applicant
from backend.services.policy import (
    calculate_emi,
    maximum_affordable_emi_inr,
    policy_violations,
)


def make_applicant(**overrides):
    values = {
        "age": 35,
        "monthly_income_inr": 60000,
        "credit_score": 720,
        "employment_years": 5,
        "current_employment_months": 24,
        "employment_type": "salaried",
        "dependents": 1,
        "residence_type": "owned",
        "existing_emi_inr": 10000,
        "requested_tenure_months": 60,
        "down_payment_inr": 100000,
    }
    values.update(overrides)
    return Applicant(**values)


def test_credit_score_below_policy_minimum_is_flagged():
    violations = policy_violations(make_applicant(credit_score=620))
    assert any(item.code == "ELIG-001" for item in violations)


def test_existing_emi_above_limit_is_flagged():
    violations = policy_violations(make_applicant(existing_emi_inr=35000))
    assert any(item.code == "ELIG-003" for item in violations)


def test_affordable_emi_capacity_accounts_for_existing_emi():
    applicant = make_applicant(existing_emi_inr=10000)
    assert maximum_affordable_emi_inr(applicant) == 20000


def test_emi_calculation_returns_positive_amount():
    emi = calculate_emi(500000, 0.12, 60)
    assert emi > 0
