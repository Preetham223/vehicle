﻿import backend.main as main
from fastapi.testclient import TestClient


client = TestClient(main.app)


def test_report_endpoint_returns_pdf(monkeypatch):
    monkeypatch.setattr(
        main,
        "build_decision_pdf",
        lambda report: b"%PDF-test-report",
    )

    response = client.post(
        "/report",
        json={
            "decision": "Rejected",
            "model_decision": "Rejected",
            "sanctioned_amount_inr": None,
            "monthly_emi_inr": None,
            "explanation": "The policy criteria were not met.",
            "sources": [
                {
                    "document_id": "VLP-001",
                    "section": "Eligibility - Credit Score",
                    "text": "Minimum score is 650.",
                }
            ],
        },
    )

    assert response.status_code == 200
    assert response.headers["content-type"].startswith("application/pdf")
    assert response.content.startswith(b"%PDF")
    assert "loan-decision.pdf" in response.headers["content-disposition"]
