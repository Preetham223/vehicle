﻿from types import SimpleNamespace

from backend.schemas import Applicant
from backend.services import explain


def make_applicant():
    return Applicant(
        age=35,
        monthly_income_inr=60000,
        credit_score=620,
        employment_years=5,
        current_employment_months=24,
        employment_type="salaried",
        dependents=1,
        residence_type="owned",
        existing_emi_inr=35000,
        requested_tenure_months=60,
        down_payment_inr=100000,
    )


class FakeOpenAI:
    def __init__(self, api_key):
        self.chat = SimpleNamespace(
            completions=SimpleNamespace(create=self.create_completion)
        )

    def create_completion(self, **kwargs):
        message = SimpleNamespace(
            content="Rejected under [VLP-001 | Eligibility - Credit Score]."
        )
        return SimpleNamespace(
            choices=[SimpleNamespace(message=message)]
        )


def test_explanation_returns_text_and_policy_sources(monkeypatch):
    monkeypatch.setattr(explain, "OpenAI", FakeOpenAI)
    monkeypatch.setattr(
        explain,
        "get_policy_section",
        lambda section: [
            {
                "document_id": "VLP-001",
                "section": section,
                "text": "The minimum credit score is 650.",
            }
        ],
    )
    monkeypatch.setenv("OPENAI_API_KEY", "test-key")

    result = explain.explain_decision(
        applicant=make_applicant(),
        approved=False,
    )

    assert "Rejected" in result["explanation"]
    assert result["sources"][0]["document_id"] == "VLP-001"
