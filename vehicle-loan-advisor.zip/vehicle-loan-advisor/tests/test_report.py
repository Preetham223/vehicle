﻿from backend.services.report import build_decision_pdf


def test_decision_report_is_a_pdf():
    pdf_bytes = build_decision_pdf(
        {
            "decision": "Rejected",
            "model_decision": "Approved",
            "sanctioned_amount_inr": None,
            "monthly_emi_inr": None,
            "explanation": "Credit score is below the policy minimum.",
            "sources": [
                {
                    "document_id": "VLP-001",
                    "section": "Eligibility - Credit Score",
                    "text": "Minimum credit score: 650.",
                }
            ],
        }
    )

    assert pdf_bytes.startswith(b"%PDF")
