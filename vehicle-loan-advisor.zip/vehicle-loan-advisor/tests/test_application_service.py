﻿from backend.schemas import Applicant
from backend.services import advisor


def make_applicant():
    return Applicant(
        age=35,
        monthly_income_inr=60000,
        credit_score=720,
        employment_years=5,
        current_employment_months=24,
        employment_type="salaried",
        dependents=1,
        residence_type="owned",
        existing_emi_inr=10000,
        requested_tenure_months=60,
        down_payment_inr=100000,
    )


def test_run_advisor_returns_full_approved_result(monkeypatch):
    monkeypatch.setattr(
        advisor,
        "predict_eligibility",
        lambda applicant: {
            "decision": "Approved",
            "model_decision": "Approved",
            "approved_probability": 0.9,
            "policy_violations": [],
        },
    )
    monkeypatch.setattr(advisor, "save_decision_audit", lambda result: 42)
    monkeypatch.setattr(
        advisor,
        "calculate_sanctioned_amount",
        lambda applicant: {
            "sanctioned_amount_inr": 500000,
            "monthly_emi_inr": 11122,
        },
    )
    monkeypatch.setattr(
        advisor,
        "list_affordable_vehicles",
        lambda applicant, amount: [{"vehicle_id": "VEH-001"}],
    )
    monkeypatch.setattr(
        advisor,
        "explain_decision",
        lambda **kwargs: {"explanation": "Policy-based explanation.", "sources": []},
    )

    result = advisor.run_advisor(make_applicant())

    assert result["audit_id"] == 42
    assert result["eligibility"]["decision"] == "Approved"
    assert result["loan"]["sanctioned_amount_inr"] == 500000
    assert result["vehicles"][0]["vehicle_id"] == "VEH-001"
    assert result["explanation"]["sources"] == []
