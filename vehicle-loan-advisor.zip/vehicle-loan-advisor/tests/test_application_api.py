﻿import backend.main as main
from fastapi.testclient import TestClient


client = TestClient(main.app)


def test_application_endpoint_returns_complete_result(monkeypatch):
    monkeypatch.setattr(
        main,
        "run_advisor",
        lambda applicant, language: {
            "audit_id": 21,
            "eligibility": {
                "decision": "Rejected",
                "model_decision": "Rejected",
                "approved_probability": 0.1,
                "policy_violations": [],
                "audit_id": 21,
            },
            "loan": None,
            "vehicles": [],
            "explanation": {
                "explanation": "The policy sources do not support approval.",
                "sources": [],
            },
        },
    )

    response = client.post(
        "/application",
        json={
            "applicant": {
                "age": 35,
                "monthly_income_inr": 60000,
                "credit_score": 620,
                "employment_years": 5,
                "current_employment_months": 24,
                "employment_type": "salaried",
                "dependents": 1,
                "residence_type": "owned",
                "existing_emi_inr": 35000,
                "requested_tenure_months": 60,
                "down_payment_inr": 100000,
            },
            "language": "English",
        },
    )

    assert response.status_code == 200
    assert response.json()["audit_id"] == 21
    assert response.json()["loan"] is None
    assert "explanation" in response.json()
