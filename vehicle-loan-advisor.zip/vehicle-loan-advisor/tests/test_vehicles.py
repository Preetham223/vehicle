﻿import pandas as pd

from backend.schemas import Applicant
from backend.services import vehicles


def test_affordable_vehicle_filter_uses_price_and_ltv(monkeypatch, tmp_path):
    catalog_path = tmp_path / "vehicle_catalog.csv"
    pd.DataFrame(
        [
            {
                "vehicle_id": "VEH-001",
                "vehicle_name": "Vehicle 001",
                "variant_id": "VEH-001-V2",
                "variant_name": "Comfort",
                "on_road_price_inr": 521700,
                "features": "ABS; Rear camera",
            },
            {
                "vehicle_id": "VEH-001",
                "vehicle_name": "Vehicle 001",
                "variant_id": "VEH-001-V3",
                "variant_name": "Premium",
                "on_road_price_inr": 610500,
                "features": "ABS; Cruise control",
            },
        ]
    ).to_csv(catalog_path, index=False)

    monkeypatch.setattr(vehicles, "CATALOG_PATH", catalog_path)

    applicant = Applicant(
        age=35,
        monthly_income_inr=60000,
        credit_score=720,
        employment_years=5,
        current_employment_months=24,
        employment_type="salaried",
        dependents=1,
        residence_type="owned",
        existing_emi_inr=10000,
        requested_tenure_months=60,
        down_payment_inr=100000,
    )

    results = vehicles.list_affordable_vehicles(
        applicant,
        sanctioned_amount_inr=500000,
    )

    assert [item["variant_id"] for item in results] == ["VEH-001-V2"]
    assert results[0]["estimated_loan_inr"] == 421700
    assert results[0]["estimated_emi_inr"] > 0
