﻿import backend.main as main
from fastapi.testclient import TestClient


client = TestClient(main.app)


def test_feedback_endpoint_records_rating(monkeypatch):
    monkeypatch.setattr(main, "save_feedback", lambda **kwargs: 7)

    response = client.post(
        "/feedback",
        json={
            "audit_id": 12,
            "rating": 5,
            "comment": "Clear explanation.",
        },
    )

    assert response.status_code == 201
    assert response.json() == {
        "feedback_id": 7,
        "status": "recorded",
    }


def test_feedback_endpoint_rejects_invalid_rating():
    response = client.post(
        "/feedback",
        json={"rating": 6},
    )

    assert response.status_code == 422
