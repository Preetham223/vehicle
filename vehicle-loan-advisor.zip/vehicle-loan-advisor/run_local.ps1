﻿$projectRoot = (Get-Location).Path

Start-Process `
    -FilePath "powershell.exe" `
    -WorkingDirectory $projectRoot `
    -ArgumentList "-NoExit", "-Command", "python -m uvicorn backend.main:app --reload"

Start-Process `
    -FilePath "powershell.exe" `
    -WorkingDirectory $projectRoot `
    -ArgumentList "-NoExit", "-Command", "python -m streamlit run frontend/app.py"

Write-Host "Backend:  http://127.0.0.1:8000"
Write-Host "API docs: http://127.0.0.1:8000/docs"
Write-Host "Frontend: http://localhost:8501"
