﻿"""Explore the synthetic loan dataset and save basic EDA outputs."""

from pathlib import Path

import matplotlib
matplotlib.use("Agg")

import matplotlib.pyplot as plt
import pandas as pd
import seaborn as sns


PROJECT_ROOT = Path(__file__).resolve().parents[1]
DATA_PATH = PROJECT_ROOT / "data" / "raw" / "synthetic_loan_applications.csv"
OUTPUT_DIR = PROJECT_ROOT / "docs" / "eda"
TARGET = "historical_decision"


def main() -> None:
    if not DATA_PATH.exists():
        raise FileNotFoundError(
            f"Dataset not found: {DATA_PATH}\n"
            "Run: python scripts\\generate_synthetic_data.py"
        )

    OUTPUT_DIR.mkdir(parents=True, exist_ok=True)
    data = pd.read_csv(DATA_PATH)

    if TARGET not in data.columns:
        raise ValueError(f"Expected target column '{TARGET}' in the dataset.")

    numeric_columns = data.select_dtypes(include="number").columns.tolist()
    decision_counts = data[TARGET].value_counts()

    summary_lines = [
        "# Loan application dataset EDA",
        "",
        "> This dataset is synthetic. The results do not represent real lending outcomes.",
        "",
        f"- Rows: {len(data):,}",
        f"- Columns: {len(data.columns)}",
        f"- Duplicate rows: {data.duplicated().sum():,}",
        f"- Missing values: {int(data.isna().sum().sum()):,}",
        "",
        "## Decision counts",
        "",
        decision_counts.to_string(),
        "",
        "## Numeric feature summary",
        "",
        data[numeric_columns].describe().round(2).to_string(),
        "",
        "## Missing values by column",
        "",
        data.isna().sum().to_string(),
        "",
    ]

    if {
        "employment_years",
        "current_employment_months",
    }.issubset(data.columns):
        inconsistent_employment = (
            data["current_employment_months"] > data["employment_years"] * 12
        ).sum()
        summary_lines.extend(
            [
                "## Employment consistency check",
                "",
                f"Rows where current job duration exceeds total experience: "
                f"{inconsistent_employment}",
                "",
            ]
        )

    (OUTPUT_DIR / "eda_summary.txt").write_text(
        "\n".join(summary_lines),
        encoding="utf-8",
    )

    sns.set_theme(style="whitegrid")

    plt.figure(figsize=(7, 5))
    sns.countplot(data=data, x=TARGET, hue=TARGET, legend=False)
    plt.title("Synthetic historical decisions")
    plt.xlabel("Decision")
    plt.ylabel("Applications")
    plt.tight_layout()
    plt.savefig(OUTPUT_DIR / "decision_counts.png", dpi=150)
    plt.close()

    if {"credit_score", TARGET}.issubset(data.columns):
        plt.figure(figsize=(8, 5))
        sns.histplot(
            data=data,
            x="credit_score",
            hue=TARGET,
            bins=30,
            element="step",
            stat="density",
            common_norm=False,
        )
        plt.title("Credit score by synthetic decision")
        plt.tight_layout()
        plt.savefig(OUTPUT_DIR / "credit_score_by_decision.png", dpi=150)
        plt.close()

    if {"monthly_income_inr", TARGET}.issubset(data.columns):
        plt.figure(figsize=(8, 5))
        sns.boxplot(
            data=data,
            x=TARGET,
            y="monthly_income_inr",
            hue=TARGET,
            legend=False,
        )
        plt.title("Monthly income by synthetic decision")
        plt.ylabel("Monthly income (INR)")
        plt.tight_layout()
        plt.savefig(OUTPUT_DIR / "income_by_decision.png", dpi=150)
        plt.close()

    print(f"Rows and columns: {data.shape}")
    print(f"Duplicate rows: {data.duplicated().sum()}")
    print(f"Missing values: {int(data.isna().sum().sum())}")
    print(f"\nDecision counts:\n{decision_counts}")
    print(f"\nEDA outputs saved to: {OUTPUT_DIR}")


if __name__ == "__main__":
    main()
