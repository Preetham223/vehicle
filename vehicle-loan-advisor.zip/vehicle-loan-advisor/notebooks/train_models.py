﻿"""Train and compare approval classifiers on the fictional dataset.

Results demonstrate the ML workflow only. Synthetic data cannot establish
real-world lending performance.
"""

import json
from pathlib import Path

import joblib
import numpy as np
import pandas as pd
from sklearn.compose import ColumnTransformer
from sklearn.ensemble import RandomForestClassifier
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import (
    balanced_accuracy_score,
    confusion_matrix,
    precision_score,
    recall_score,
    roc_auc_score,
)
from sklearn.model_selection import train_test_split
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import OneHotEncoder, StandardScaler
from sklearn.impute import SimpleImputer


PROJECT_ROOT = Path(__file__).resolve().parents[1]
DATA_PATH = PROJECT_ROOT / "data" / "raw" / "synthetic_loan_applications.csv"
MODEL_DIR = PROJECT_ROOT / "models"
MODEL_PATH = MODEL_DIR / "eligibility_model.joblib"
METRICS_PATH = PROJECT_ROOT / "docs" / "model_metrics.json"

TARGET = "historical_decision"
FALSE_APPROVAL_COST = 5
FALSE_REJECTION_COST = 1
THRESHOLDS = np.arange(0.10, 0.91, 0.01)


def make_preprocessor(
    numeric_features: list[str],
    categorical_features: list[str],
) -> ColumnTransformer:
    numeric_pipeline = Pipeline(
        steps=[
            ("imputer", SimpleImputer(strategy="median")),
            ("scaler", StandardScaler()),
        ]
    )

    categorical_pipeline = Pipeline(
        steps=[
            ("imputer", SimpleImputer(strategy="most_frequent")),
            ("onehot", OneHotEncoder(handle_unknown="ignore")),
        ]
    )

    return ColumnTransformer(
        transformers=[
            ("numeric", numeric_pipeline, numeric_features),
            ("categorical", categorical_pipeline, categorical_features),
        ]
    )


def score_threshold(
    y_true: pd.Series,
    probabilities: np.ndarray,
) -> dict:
    """Choose a threshold that minimizes the assumed validation error cost."""
    best_result = None

    for threshold in THRESHOLDS:
        predictions = (probabilities >= threshold).astype(int)
        matrix = confusion_matrix(y_true, predictions, labels=[0, 1])
        false_approval = int(matrix[0, 1])
        false_rejection = int(matrix[1, 0])
        cost = (
            FALSE_APPROVAL_COST * false_approval
            + FALSE_REJECTION_COST * false_rejection
        )

        candidate = {
            "threshold": float(threshold),
            "cost": int(cost),
            "false_approval": false_approval,
            "false_rejection": false_rejection,
            "balanced_accuracy": float(
                balanced_accuracy_score(y_true, predictions)
            ),
            "precision": float(
                precision_score(y_true, predictions, zero_division=0)
            ),
            "recall": float(recall_score(y_true, predictions, zero_division=0)),
            "roc_auc": float(roc_auc_score(y_true, probabilities)),
            "confusion_matrix": matrix.tolist(),
        }

        if best_result is None or candidate["cost"] < best_result["cost"]:
            best_result = candidate

    return best_result


def main() -> None:
    if not DATA_PATH.exists():
        raise FileNotFoundError(
            f"Dataset not found: {DATA_PATH}\n"
            "Run: python scripts\\generate_synthetic_data.py"
        )

    data = pd.read_csv(DATA_PATH)
    if TARGET not in data.columns:
        raise ValueError(f"Dataset must contain the '{TARGET}' column.")

    y = data[TARGET].map({"rejected": 0, "approved": 1})
    if y.isna().any():
        raise ValueError("The target column contains an unknown decision value.")

    X = data.drop(columns=[TARGET])
    numeric_features = X.select_dtypes(include="number").columns.tolist()
    categorical_features = X.select_dtypes(exclude="number").columns.tolist()

    X_train, X_remaining, y_train, y_remaining = train_test_split(
        X,
        y,
        test_size=0.40,
        random_state=42,
        stratify=y,
    )
    X_validation, X_test, y_validation, y_test = train_test_split(
        X_remaining,
        y_remaining,
        test_size=0.50,
        random_state=42,
        stratify=y_remaining,
    )

    candidates = {
        "logistic_regression": LogisticRegression(max_iter=2000),
        "random_forest": RandomForestClassifier(
            n_estimators=300,
            min_samples_leaf=3,
            random_state=42,
            n_jobs=-1,
        ),
    }

    validation_results = {}
    trained_candidates = {}

    for name, classifier in candidates.items():
        pipeline = Pipeline(
            steps=[
                (
                    "preprocessor",
                    make_preprocessor(numeric_features, categorical_features),
                ),
                ("classifier", classifier),
            ]
        )
        pipeline.fit(X_train, y_train)
        probabilities = pipeline.predict_proba(X_validation)[:, 1]
        result = score_threshold(y_validation, probabilities)

        validation_results[name] = result
        trained_candidates[name] = pipeline

        print(
            f"{name}: validation cost={result['cost']}, "
            f"threshold={result['threshold']:.2f}, "
            f"balanced accuracy={result['balanced_accuracy']:.3f}, "
            f"ROC-AUC={result['roc_auc']:.3f}"
        )

    best_name = min(
        validation_results,
        key=lambda name: (
            validation_results[name]["cost"],
            -validation_results[name]["roc_auc"],
        ),
    )
    best_threshold = validation_results[best_name]["threshold"]

    X_train_validation = pd.concat([X_train, X_validation], axis=0)
    y_train_validation = pd.concat([y_train, y_validation], axis=0)

    final_model = Pipeline(
        steps=[
            (
                "preprocessor",
                make_preprocessor(numeric_features, categorical_features),
            ),
            ("classifier", candidates[best_name]),
        ]
    )
    final_model.fit(X_train_validation, y_train_validation)

    test_probabilities = final_model.predict_proba(X_test)[:, 1]
    test_predictions = (test_probabilities >= best_threshold).astype(int)
    test_matrix = confusion_matrix(y_test, test_predictions, labels=[0, 1])

    test_results = {
        "threshold": float(best_threshold),
        "balanced_accuracy": float(
            balanced_accuracy_score(y_test, test_predictions)
        ),
        "precision": float(
            precision_score(y_test, test_predictions, zero_division=0)
        ),
        "recall": float(recall_score(y_test, test_predictions, zero_division=0)),
        "roc_auc": float(roc_auc_score(y_test, test_probabilities)),
        "confusion_matrix_labels": ["rejected", "approved"],
        "confusion_matrix": test_matrix.tolist(),
        "false_approval_count": int(test_matrix[0, 1]),
        "false_rejection_count": int(test_matrix[1, 0]),
    }

    MODEL_DIR.mkdir(parents=True, exist_ok=True)
    METRICS_PATH.parent.mkdir(parents=True, exist_ok=True)

    joblib.dump(
        {
            "model": final_model,
            "threshold": best_threshold,
            "features": X.columns.tolist(),
            "target_mapping": {"rejected": 0, "approved": 1},
            "selected_model": best_name,
        },
        MODEL_PATH,
    )

    report = {
        "dataset": "synthetic_loan_applications.csv",
        "dataset_rows": int(len(data)),
        "split": {
            "train": int(len(X_train)),
            "validation": int(len(X_validation)),
            "test": int(len(X_test)),
        },
        "selection_rule": (
            "Choose the validation threshold/model with the lowest cost; "
            "false approval cost is 5 and false rejection cost is 1."
        ),
        "validation_comparison": validation_results,
        "selected_model": best_name,
        "test_results": test_results,
        "limitations": [
            "All applications and outcomes are synthetic.",
            "Metrics do not estimate performance on real lending applications.",
            "The selected model supports the capstone demonstration only.",
        ],
    }
    METRICS_PATH.write_text(json.dumps(report, indent=2), encoding="utf-8")

    print(f"\nSelected model: {best_name}")
    print(f"Test results: {test_results}")
    print(f"Saved model: {MODEL_PATH}")
    print(f"Saved metrics: {METRICS_PATH}")


if __name__ == "__main__":
    main()
