# Model Evaluation Report

Generated from `docs/model_metrics.json` by `scripts/build_evaluation_report.py`.

## Data splits
- Train: 3000
- Validation: 1000
- Test: 1000

## Model selection
- Selected model: logistic_regression
- Selection rule: Choose the validation threshold/model with the lowest cost; false approval cost is 5 and false rejection cost is 1.

## Validation comparison

| Model | Threshold | Cost | Balanced accuracy | Precision | Recall | ROC AUC |
|---|---:|---:|---:|---:|---:|---:|
| logistic_regression | 0.8800 | 409 | 0.7589 | 0.9535 | 0.6162 | 0.8566 |
| random_forest | 0.8300 | 456 | 0.7407 | 0.9339 | 0.6266 | 0.8325 |

## Held-out test results

- Threshold: 0.8800
- Balanced accuracy: 0.7544
- Precision: 0.9529
- Recall: 0.6070
- ROC AUC: 0.8565
- False approvals: 23
- False rejections: 301

### Confusion matrix

Rows and columns follow the label order: rejected, approved.

```text
  211  23
  301  465
```

## Limitations

- All applications and outcomes are synthetic.
- Metrics do not estimate performance on real lending applications.
- The selected model supports the capstone demonstration only.

Metrics above are copied from the training run output. They should be interpreted in light of the dataset and limitations.
