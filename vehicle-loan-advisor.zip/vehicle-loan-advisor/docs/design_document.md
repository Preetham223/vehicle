﻿# Vehicle Loan Advisor — Design Document

## Purpose
The system evaluates vehicle loan applications against configured policy rules, estimates an eligible loan amount, recommends vehicles from the catalog, and explains decisions using retrieved policy sources.

## Architecture
- **Streamlit frontend:** collects applicant and vehicle preferences and displays results.
- **FastAPI backend:** exposes the advisor API and coordinates the services.
- **Eligibility service:** uses the trained model to estimate approval likelihood.
- **Policy service:** applies mandatory policy rules and affordability limits.
- **Loan amount service:** calculates an amount from affordability, tenure, and vehicle constraints.
- **Vehicle service:** searches the vehicle catalog and checks relevant vehicle information.
- **Explanation service:** uses OpenAI and retrieved policy passages to explain the result.
- **SQLite/database services:** store application audit and feedback records.
- **Model and data files:** contain the trained eligibility artifact, training data, policy documents, and vehicle catalog.

## Decision flow
1. The frontend submits applicant details to the backend.
2. The backend validates the request.
3. The policy service checks mandatory eligibility rules and affordability.
4. The eligibility model estimates the outcome using the saved model and threshold.
5. Mandatory policy failures take precedence over the model estimate.
6. If eligible, the loan amount and vehicle recommendations are calculated.
7. The explanation service retrieves relevant policy sources and explains the result.
8. The backend returns the decision, amount, recommendations, explanation, and sources.

## Policy and model responsibilities
Policy rules are authoritative for mandatory conditions, such as minimum credit score and maximum existing-obligation ratio. The model estimates an outcome from historical or synthetic training data; it does not override a mandatory policy failure and does not calculate the sanctioned amount. The loan amount service performs that calculation.

## Model evaluation
The training script compares candidate classifiers on a validation split, selects a model and threshold according to its configured selection rule, then evaluates the selected model on a held-out test split. See `model_evaluation_report.md` for results generated from the training run's `model_metrics.json`.

## Limitations
- Results depend on the quality and representativeness of the training data and policy documents.
- Synthetic training data does not establish real-world lending performance.
- The explanation is informational and should be traceable to retrieved policy sources.
- Final lending decisions require review under the lender's approved policies and processes.
