﻿$ErrorActionPreference = "Stop"

if (-not (Test-Path ".venv\Scripts\python.exe")) {
    python -m venv .venv
}

$projectPython = Join-Path (Get-Location).Path ".venv\Scripts\python.exe"

& $projectPython -m pip install --upgrade pip
& $projectPython -m pip install -r requirements.txt

$requiredFolders = @(
    "data\raw",
    "data\processed",
    "data\documents\policy",
    "data\documents\vehicles",
    "models",
    "vectorstore",
    "tests",
    "docs"
)

foreach ($folder in $requiredFolders) {
    New-Item -ItemType Directory -Force -Path $folder | Out-Null
}

if (-not (Test-Path ".env") -and (Test-Path ".env.example")) {
    Copy-Item ".env.example" ".env"
}

Write-Host "Project setup finished."
Write-Host "Add OPENAI_API_KEY to .env if it is not already set."
