﻿"""Create a fictional vehicle catalogue and matching brochure documents."""

import json
from pathlib import Path


PROJECT_ROOT = Path(__file__).resolve().parents[1]
CATALOGUE_PATH = PROJECT_ROOT / "data" / "raw" / "vehicle_catalogue.json"
BROCHURE_DIR = PROJECT_ROOT / "data" / "documents" / "vehicles"

# Name, body type, fuel type, base ex-showroom price, seats.
MODEL_SPECS = [
    ("Aster Mini", "hatchback", "petrol", 400000, 5),
    ("Aster Go", "hatchback", "petrol", 480000, 5),
    ("Aster City", "hatchback", "petrol", 560000, 5),
    ("Aster Plus", "hatchback", "petrol", 650000, 5),
    ("Aster Sport", "hatchback", "petrol", 760000, 5),
    ("Meridian Lite", "sedan", "petrol", 680000, 5),
    ("Meridian City", "sedan", "petrol", 800000, 5),
    ("Meridian Comfort", "sedan", "petrol", 950000, 5),
    ("Meridian Tour", "sedan", "diesel", 1100000, 5),
    ("Meridian Grand", "sedan", "petrol", 1350000, 5),
    ("Crest Mini", "compact_suv", "petrol", 750000, 5),
    ("Crest Urban", "compact_suv", "petrol", 900000, 5),
    ("Crest Trail", "compact_suv", "diesel", 1050000, 5),
    ("Crest Plus", "compact_suv", "petrol", 1200000, 5),
    ("Crest Elite", "compact_suv", "diesel", 1450000, 5),
    ("Summit Family", "suv", "diesel", 1500000, 7),
    ("Summit Trail", "suv", "diesel", 1750000, 7),
    ("Summit Grand", "suv", "diesel", 2100000, 7),
    ("Voyager Family", "mpv", "petrol", 1000000, 7),
    ("Voyager Tour", "mpv", "diesel", 1400000, 7),
    ("Volt Mini", "hatchback", "electric", 850000, 5),
    ("Volt City", "hatchback", "electric", 1050000, 5),
    ("Volt Urban", "compact_suv", "electric", 1350000, 5),
    ("Volt Trail", "suv", "electric", 1800000, 5),
    ("Volt Grand", "suv", "electric", 2400000, 5),
]

BODY_PROFILES = {
    "hatchback": {
        "engine_cc": 1200, "power_kw": 60, "mileage_kmpl": 20,
        "boot_litres": 280,
        "description": (
            "A compact vehicle for city commutes. Its smaller body makes "
            "urban parking easier, while luggage space suits everyday use."
        ),
    },
    "sedan": {
        "engine_cc": 1500, "power_kw": 85, "mileage_kmpl": 17,
        "boot_litres": 450,
        "description": (
            "A passenger car with a separate luggage compartment. "
            "Designed for commuting and longer journeys with family luggage."
        ),
    },
    "compact_suv": {
        "engine_cc": 1500, "power_kw": 90, "mileage_kmpl": 16,
        "boot_litres": 380,
        "description": (
            "A compact utility vehicle with an elevated seating position. "
            "Combines everyday passenger use with flexible luggage space."
        ),
    },
    "suv": {
        "engine_cc": 2000, "power_kw": 120, "mileage_kmpl": 13,
        "boot_litres": 200,
        "description": (
            "A larger utility vehicle for passengers and touring. "
            "Check the stated seat count; luggage capacity is measured "
            "with all listed seats in use. Four-wheel drive is not specified."
        ),
    },
    "mpv": {
        "engine_cc": 1500, "power_kw": 80, "mileage_kmpl": 16,
        "boot_litres": 180,
        "description": (
            "A seven-seat passenger vehicle for larger families. "
            "The stated luggage capacity assumes all seats are in use."
        ),
    },
}

TRIMS = [
    ("Base", 0),
    ("Comfort", 70000),
    ("Premium", 150000),
]


def main() -> None:
    CATALOGUE_PATH.parent.mkdir(parents=True, exist_ok=True)
    BROCHURE_DIR.mkdir(parents=True, exist_ok=True)
    vehicles = []

    for index, (name, body, fuel, base_price, seats) in enumerate(
        MODEL_SPECS, start=1
    ):
        vehicle_id = f"VEH-{index:03d}"
        profile = BODY_PROFILES[body]
        electric = fuel == "electric"
        variants = []

        for trim_index, (trim, surcharge) in enumerate(TRIMS, start=1):
            ex_showroom = base_price + surcharge
            registration = round(ex_showroom * 0.08)
            insurance = round(ex_showroom * 0.03)
            on_road = ex_showroom + registration + insurance

            features = [
                "Air conditioning",
                "Power steering",
                "ABS",
                "Rear parking sensors",
            ]
            if trim_index >= 2:
                features.extend(["Touchscreen display", "Rear camera"])
            if trim_index == 3:
                features.extend(["Cruise control", "Electronic stability control"])

            specifications = {
                "seating_capacity": seats,
                "boot_capacity_litres": profile["boot_litres"],
                "power_kw": profile["power_kw"] + (15 if electric else 0),
                "airbags": 6 if trim_index == 3 else 2,
            }

            if electric:
                specifications.update({
                    "battery_capacity_kwh": 30 if base_price < 1200000 else 50,
                    "estimated_energy_consumption_kwh_per_100km": (
                        12 if body == "hatchback" else 16
                    ),
                })
                transmission = "automatic"
            else:
                specifications.update({
                    "engine_capacity_cc": profile["engine_cc"],
                    "estimated_mileage_kmpl": (
                        profile["mileage_kmpl"] + (2 if fuel == "diesel" else 0)
                    ),
                })
                transmission = "automatic" if trim_index == 3 else "manual"

            variants.append({
                "variant_id": f"{vehicle_id}-V{trim_index}",
                "name": trim,
                "transmission": transmission,
                "ex_showroom_price_inr": ex_showroom,
                "registration_inr": registration,
                "insurance_inr": insurance,
                "on_road_price_inr": on_road,
                "specifications": specifications,
                "features": features,
            })

        vehicle = {
            "vehicle_id": vehicle_id,
            "manufacturer": "Fictional Motors",
            "model": name,
            "body_type": body,
            "fuel_type": fuel,
            "description": profile["description"],
            "data_source": "Synthetic capstone catalogue",
            "brochure_document_id": f"BROCHURE-{index:03d}",
            "variants": variants,
        }
        vehicles.append(vehicle)

        brochure_lines = [
            f"DOCUMENT ID: BROCHURE-{index:03d}",
            f"TITLE: {name} - Fictional Vehicle Brochure",
            f"VEHICLE ID: {vehicle_id}",
            "",
            "SECTION: Data Source",
            "All names, prices, specifications and features are fictional.",
            "Efficiency figures are illustrative estimates, not certified values.",
            "",
            "SECTION: Overview",
            f"Model: {name}",
            f"Body type: {body}",
            f"Fuel type: {fuel}",
            profile["description"],
            "",
        ]

        for variant in variants:
            brochure_lines.extend([
                f"SECTION: Variant - {variant['name']}",
                f"Variant ID: {variant['variant_id']}",
                f"Transmission: {variant['transmission']}",
                f"Ex-showroom price: INR {variant['ex_showroom_price_inr']:,}",
                f"Registration: INR {variant['registration_inr']:,}",
                f"Insurance: INR {variant['insurance_inr']:,}",
                f"On-road price: INR {variant['on_road_price_inr']:,}",
                "Specifications: " + json.dumps(variant["specifications"]),
                "Features: " + ", ".join(variant["features"]),
                "",
            ])

        brochure_lines.extend([
            "SECTION: Information Limits",
            "Warranty, delivery time, charging time, crash-test rating and",
            "dealer discounts are not supplied. Do not infer these facts.",
        ])

        (BROCHURE_DIR / f"{vehicle_id}.txt").write_text(
            "\n".join(brochure_lines), encoding="utf-8"
        )

    # Validate the catalogue before saving it.
    assert len(vehicles) >= 25
    assert len({v["vehicle_id"] for v in vehicles}) == len(vehicles)
    for vehicle in vehicles:
        for variant in vehicle["variants"]:
            assert variant["on_road_price_inr"] == (
                variant["ex_showroom_price_inr"]
                + variant["registration_inr"]
                + variant["insurance_inr"]
            )

    CATALOGUE_PATH.write_text(
        json.dumps(vehicles, indent=2), encoding="utf-8"
    )
    print(f"Created vehicle models: {len(vehicles)}")
    print(f"Created variants: {sum(len(v['variants']) for v in vehicles)}")
    print(f"Catalogue saved to: {CATALOGUE_PATH}")
    print(f"Brochures saved to: {BROCHURE_DIR}")


if __name__ == "__main__":
    main()
