﻿$ErrorActionPreference = "Stop"
$baseUrl = "http://127.0.0.1:8000"

Write-Host "Checking API health..."
$health = Invoke-RestMethod -Method Get -Uri "$baseUrl/health"
$health | ConvertTo-Json -Depth 5

Write-Host "`nChecking application readiness..."
try {
    $readiness = Invoke-RestMethod -Method Get -Uri "$baseUrl/ready"
    $readiness | ConvertTo-Json -Depth 5
}
catch {
    Write-Host "Readiness check returned an error. Check the model, catalogue, vectorstore, and API key."
    throw
}

Write-Host "`nAPI smoke checks completed."
