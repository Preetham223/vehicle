﻿$ErrorActionPreference = "Stop"

$projectRoot = (Get-Location).Path
$projectPython = Join-Path $projectRoot ".venv\Scripts\python.exe"

if (-not (Test-Path $projectPython)) {
    throw "Virtual environment not found. Run .\scripts\setup_project.ps1 first."
}

Start-Process `
    -FilePath $projectPython `
    -WorkingDirectory $projectRoot `
    -ArgumentList @(
        "-m",
        "uvicorn",
        "backend.main:app",
        "--reload"
    )

Start-Process `
    -FilePath $projectPython `
    -WorkingDirectory $projectRoot `
    -ArgumentList @(
        "-m",
        "streamlit",
        "run",
        "frontend/app.py"
    )

Write-Host "Backend:  http://127.0.0.1:8000"
Write-Host "API docs: http://127.0.0.1:8000/docs"
Write-Host "Frontend: http://localhost:8501"
