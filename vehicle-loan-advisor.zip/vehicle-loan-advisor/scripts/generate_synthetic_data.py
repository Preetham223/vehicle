﻿"""Generate fictional loan application data for the capstone.

The rows and outcomes are simulated. They are not real customer data or
evidence of real-world lending performance.
"""

from pathlib import Path

import numpy as np
import pandas as pd


def main() -> None:
    rng = np.random.default_rng(42)
    row_count = 5000

    age = rng.integers(21, 71, size=row_count)
    employment_type = rng.choice(
        ["salaried", "self_employed"],
        size=row_count,
        p=[0.72, 0.28],
    )

    employment_years = np.minimum(
        rng.uniform(0.0, 1.0, size=row_count) * (age - 18),
        45,
    )
    current_employment_months = (
        employment_years
        * 12
        * rng.uniform(0.1, 1.0, size=row_count)
    ).astype(int)

    monthly_income_inr = np.clip(
        rng.lognormal(mean=np.log(55_000), sigma=0.55, size=row_count),
        15_000,
        500_000,
    ).round(0)

    credit_score = np.clip(
        rng.normal(loc=680, scale=75, size=row_count),
        300,
        900,
    ).astype(int)

    obligation_ratio = rng.beta(a=2, b=5, size=row_count) * 0.9
    existing_emi_inr = (monthly_income_inr * obligation_ratio).round(0)

    requested_tenure_months = rng.choice(
        [12, 24, 36, 48, 60, 72, 84],
        size=row_count,
    )
    dependents = rng.integers(0, 6, size=row_count)
    residence_type = rng.choice(
        ["owned", "rented"],
        size=row_count,
        p=[0.55, 0.45],
    )
    down_payment_inr = rng.uniform(0, 1_500_000, size=row_count).round(0)

    # Simulate past approval patterns with a probabilistic risk score.
    # This is only for demonstrating the ML workflow.
    logit = (
        (credit_score - 650) / 55
        + 0.45 * np.log(monthly_income_inr / 50_000)
        - 4.0 * (obligation_ratio - 0.35)
        + 0.12 * (employment_years - 3)
        - 0.15 * (requested_tenure_months / 84)
        - 0.08 * dependents
    )
    approval_probability = 1 / (1 + np.exp(-logit))
    approved = rng.binomial(1, approval_probability)

    data = pd.DataFrame(
        {
            "age": age,
            "monthly_income_inr": monthly_income_inr,
            "credit_score": credit_score,
            "employment_years": employment_years.round(1),
            "current_employment_months": current_employment_months,
            "employment_type": employment_type,
            "dependents": dependents,
            "residence_type": residence_type,
            "existing_emi_inr": existing_emi_inr,
            "requested_tenure_months": requested_tenure_months,
            "down_payment_inr": down_payment_inr,
            "historical_decision": np.where(approved == 1, "approved", "rejected"),
        }
    )

    project_root = Path(__file__).resolve().parents[1]
    output_path = project_root / "data" / "raw" / "synthetic_loan_applications.csv"
    output_path.parent.mkdir(parents=True, exist_ok=True)
    data.to_csv(output_path, index=False)

    print(f"Created {len(data)} fictional applications: {output_path}")
    print(data["historical_decision"].value_counts())


if __name__ == "__main__":
    main()
