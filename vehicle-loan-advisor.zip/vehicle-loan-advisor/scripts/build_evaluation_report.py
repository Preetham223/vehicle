﻿import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
METRICS_PATH = ROOT / "docs" / "model_metrics.json"
REPORT_PATH = ROOT / "docs" / "model_evaluation_report.md"


def fmt(value):
    if value is None:
        return "not reported"
    if isinstance(value, float):
        return f"{value:.4f}"
    return str(value)


def main():
    if not METRICS_PATH.exists():
        raise SystemExit(
            "Metrics file not found. Run: python notebooks\\train_models.py"
        )

    data = json.loads(METRICS_PATH.read_text(encoding="utf-8"))
    lines = [
        "# Model Evaluation Report",
        "",
        "Generated from `docs/model_metrics.json` by "
        "`scripts/build_evaluation_report.py`.",
        "",
        "## Data splits",
    ]

    splits = data.get("split", {})
    if splits:
        for name, count in splits.items():
            lines.append(f"- {name.title()}: {count}")
    else:
        lines.append("- Split counts were not reported.")

    lines += [
        "",
        "## Model selection",
        f"- Selected model: {data.get('selected_model', 'not reported')}",
        f"- Selection rule: {data.get('selection_rule', 'not reported')}",
        "",
        "## Validation comparison",
        "",
        "| Model | Threshold | Cost | Balanced accuracy | Precision | Recall | ROC AUC |",
        "|---|---:|---:|---:|---:|---:|---:|",
    ]

    comparison = data.get("validation_comparison", {})
    if comparison:
        for name, metrics in comparison.items():
            lines.append(
                f"| {name} | {fmt(metrics.get('threshold'))} "
                f"| {fmt(metrics.get('cost'))} "
                f"| {fmt(metrics.get('balanced_accuracy'))} "
                f"| {fmt(metrics.get('precision'))} "
                f"| {fmt(metrics.get('recall'))} "
                f"| {fmt(metrics.get('roc_auc'))} |"
            )
    else:
        lines.append("| No validation comparison was reported. | — | — | — | — | — | — |")

    test = data.get("test_results", {})
    lines += [
        "",
        "## Held-out test results",
        "",
        f"- Threshold: {fmt(test.get('threshold'))}",
        f"- Balanced accuracy: {fmt(test.get('balanced_accuracy'))}",
        f"- Precision: {fmt(test.get('precision'))}",
        f"- Recall: {fmt(test.get('recall'))}",
        f"- ROC AUC: {fmt(test.get('roc_auc'))}",
        f"- False approvals: {fmt(test.get('false_approval_count'))}",
        f"- False rejections: {fmt(test.get('false_rejection_count'))}",
        "",
        "### Confusion matrix",
        "",
    ]

    labels = test.get("confusion_matrix_labels", [])
    matrix = test.get("confusion_matrix", [])
    if matrix:
        if labels:
            lines.append("Rows and columns follow the label order: " + ", ".join(labels) + ".")
        lines.append("")
        lines.append("```text")
        lines.extend("  " + "  ".join(map(str, row)) for row in matrix)
        lines.append("```")
    else:
        lines.append("The test confusion matrix was not reported.")

    lines += ["", "## Limitations", ""]
    limitations = data.get("limitations", [])
    if limitations:
        lines.extend(f"- {item}" for item in limitations)
    else:
        lines.append("- No limitations were included in the metrics file.")

    lines += [
        "",
        "Metrics above are copied from the training run output. "
        "They should be interpreted in light of the dataset and limitations.",
        "",
    ]

    REPORT_PATH.write_text("\n".join(lines), encoding="utf-8")
    print(f"Created {REPORT_PATH}")


if __name__ == "__main__":
    main()
