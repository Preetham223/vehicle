﻿from pathlib import Path

import pandas as pd


PROJECT_ROOT = Path(__file__).resolve().parents[1]
CATALOG_PATH = PROJECT_ROOT / "data" / "raw" / "vehicle_catalog.csv"

REQUIRED_COLUMNS = {
    "vehicle_id",
    "vehicle_name",
    "variant_id",
    "variant_name",
    "on_road_price_inr",
    "features",
    "source_document_id",
}


def main():
    if not CATALOG_PATH.exists():
        raise FileNotFoundError(f"Catalogue not found: {CATALOG_PATH}")

    catalog = pd.read_csv(CATALOG_PATH)
    missing = REQUIRED_COLUMNS - set(catalog.columns)
    if missing:
        raise ValueError(f"Missing columns: {sorted(missing)}")

    if catalog.empty:
        raise ValueError("The vehicle catalogue is empty.")

    if catalog["variant_id"].duplicated().any():
        duplicates = catalog.loc[
            catalog["variant_id"].duplicated(), "variant_id"
        ].tolist()
        raise ValueError(f"Duplicate variant IDs: {duplicates}")

    if catalog[list(REQUIRED_COLUMNS)].isna().any().any():
        raise ValueError("Required catalogue fields contain empty values.")

    if (catalog["on_road_price_inr"] <= 0).any():
        raise ValueError("Every on-road price must be greater than zero.")

    print(f"Catalogue is valid: {len(catalog)} variants found.")


if __name__ == "__main__":
    main()
