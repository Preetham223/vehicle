﻿from getpass import getpass
from pathlib import Path

from dotenv import set_key
from openai import OpenAI, AuthenticationError, APIStatusError


def main():
    key = getpass("Paste your NEW OpenAI key here (hidden): ").strip()
    if not key.startswith("sk-"):
        raise SystemExit("No valid-looking key entered.")

    try:
        with OpenAI(api_key=key, timeout=30.0, max_retries=0) as client:
            result = client.embeddings.create(
                model="text-embedding-3-small",
                input="Vehicle loan policy",
                dimensions=768,
            )
    except AuthenticationError:
        raise SystemExit(
            "OpenAI rejected this key. Copy the complete secret "
            "from a newly created OpenAI API key."
        )
    except APIStatusError as error:
        raise SystemExit(
            f"HTTP {error.status_code}; error code: {error.code}. "
            "Configuration was not changed."
        )

    env_path = Path(__file__).resolve().parents[1] / ".env"
    env_path.touch(exist_ok=True)

    for name, value in {
        "OPENAI_API_KEY": key,
        "OPENAI_EMBEDDING_MODEL": "text-embedding-3-small",
        "EMBEDDING_DIMENSIONS": "768",
    }.items():
        set_key(str(env_path), name, value, encoding="utf-8-sig")

    print("OpenAI embedding connection successful")
    print("Embedding dimensions:", len(result.data[0].embedding))
    print("Working configuration saved.")


if __name__ == "__main__":
    main()
