﻿$ErrorActionPreference = "Stop"

python -m pytest
if ($LASTEXITCODE -ne 0) {
    exit $LASTEXITCODE
}

Write-Host "Test suite completed successfully."
